#include "TM4C123.h"                    // Device header

#define GPIO_PORTB_CLOCK_EN 0x02 // Port B clock gating control  (b 0000 0010)
#define GPIO_PORTB_AFSEL_EN 0x04 // Port B alternate function enable
#define GPIO_PORTB_PCTL_CCP 0x700 // Port B pin 2 configured as T3CCP0
#define GPIO_PORTB_PIN2_EN 0x04  // Port B pin 2 digital enable
#define GPIO_PORTB_PIN2_IP 0x04  // Port B pin 2 as digital input
#define GPIO_PORTB_PIN2 0x04 		 // Mask for pin 2 write operation (0000 0100)

unsigned volatile long j;
uint32_t edge_count = 0;

void PB2_as_T3CCP0_Init(void);
void timer3A_RisingEdgeEvent_Init(void);
int timer3A_RisingEdgeEvent_Capture(void);


int main(){
	// Initialize PortB pin 2 as T3CCP0
	PB2_as_T3CCP0_Init();
	// Initialize Timer3A as Rising Edge Event Counter
	timer3A_RisingEdgeEvent_Init();
	
	while(1){
		edge_count = timer3A_RisingEdgeEvent_Capture();
	}
}

void PB2_as_T3CCP0_Init(void){
	// Step 1: Clock enable on PortB
	SYSCTL->RCGCGPIO |= GPIO_PORTB_CLOCK_EN;
	for (j =0; j < 3 ; j++)		// at least 3 clock cyles
	
	// Step 2: APB is selected for PortB by selecting
	// 0x40005000 as Base Address in DATA section
	
	// Step 3: Enable alternate functionality on PortB
	GPIOB->AFSEL |= GPIO_PORTB_AFSEL_EN;
	
	// Step 4: Enable digital pin functionaliy on PortB pin 2
	GPIOB->DEN |= GPIO_PORTB_PIN2_EN; // Digital enable for PB2
	
	// Step 5: Set PortB pin 2 as an input pin
	GPIOB->DIR &= ~GPIO_PORTB_PIN2_IP; // PB2 as input
	
	// Step 6: Configure PortB pin 2 as T3CCP0 pin (Table 10-2 of Datasheet, page # 651)
	GPIOB->PCTL &= ~0x00000F00;		// clear the bit fields
	GPIOB->PCTL |= GPIO_PORTB_PCTL_CCP;
}

void timer3A_RisingEdgeEvent_Init(void){
	
	// Step 1: Enable Timer Clock on timer3
	SYSCTL->RCGCTIMER |= 0x08;		// b 0000 1000
	for (j =0; j < 3 ; j++)		// at least 3 clock cyles
	
	// Step 2: Ensure Timer is disabled before making any changes
	TIMER3->CTL = 0x00;					// TAEN = 0, i.e., timer3A is disablled
	
	// Step 3: Select Mode of Operation of timer3 (Split/cancatenated/RTC)
	TIMER3->CFG = 0x04;					// timer3 is used as a 16-bit (split) timer, i.e., timer3A
	TIMER3->TAMR = 0x13; 				// TAMR = 3 (capture), TACMR = 0 (edge-count) TACDIR = 1 (count-up)
	
	// Step 4: Set counter value limit, comparted to TAR to determine match event
	TIMER3->TAMATCHR = 0xFFFF;		// 
	TIMER3->TAPMR = 0xFF;		// used with TAMATCHR to expand to 0xFFFFFF with 8-bit prescaler (bit 16:23)

	// Step 5: Interrupt configurations
	TIMER3->ICR = 0x01;					// Clear timer status flag (TATORIS, TATOMIS)
	
	// Step 6: Enable the Timer and start counting
	TIMER3->CTL |= 0x01;					// TAEN = 1
}

int timer3A_RisingEdgeEvent_Capture(void){
	return TIMER3->TAR;	// Compared with TAMATCHR to determine match event
				// contains the number of edges that have occurred
}